<?php foreach($page_detail as $page) :?>


    <?php echo $page->deskripsi; ?>
<?php endforeach; ?>